package at.fhv.sysarch.lab3.rendering;

public enum RenderingMode {
    POINT,
    WIREFRAME,
    FILLED
}